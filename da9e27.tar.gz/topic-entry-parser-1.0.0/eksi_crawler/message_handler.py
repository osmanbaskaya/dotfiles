import contextlib
from time import sleep

from google.cloud import pubsub_v1

import logging

logger = logging.getLogger(__name__)


class LogicalInconsistency(Exception):
    pass


class SyncMessageHandler:
    def __init__(
        self, project, subscription_id=None, topic_id=None, create_if_not_exist=False
    ):
        if subscription_id is None:
            raise ValueError("Subscription ID cannot be None.")

        self.project = project
        self.subscriber_client = pubsub_v1.SubscriberClient()

        self.subscription_id = subscription_id

        self.subscription_path = self.subscriber_client.subscription_path(
            self.project, self.subscription_id
        )
        if create_if_not_exist:
            self._create_subscription_if_not_exist(topic_id)

        self.consumer_fn = None

    def _create_subscription_if_not_exist(self, topic_id):
        subscription_ids = set()
        for subscription in self.subscriber_client.list_subscriptions(
            request={"project": f"projects/{self.project}"}
        ):
            subscription_ids.add(subscription.name.rsplit("/")[-1])

        if self.subscription_id not in subscription_ids:
            self._create_subscription(topic_id)

    def _create_subscription(self, topic_id):
        publisher = pubsub_v1.PublisherClient()
        logger.info(f"Creating a subscription on {topic_id} first.")
        topic_path = publisher.topic_path(self.project, topic_id)

        r = self.subscriber_client.create_subscription(
            request={"name": self.subscription_path, "topic": topic_path}
        )

        logger.info(r)

    def close(self):
        self.subscriber_client.close()

    @contextlib.contextmanager
    def get_message(self):

        while True:
            try:
                response = self.subscriber_client.pull(
                    request={"subscription": self.subscription_path, "max_messages": 1}
                )
                num_of_messages = len(response.received_messages)
                if num_of_messages == 0:
                    logger.info(
                        f"No message found via {self.subscription_path}. Sleeping 30s. "
                        "Will try later"
                    )
                    sleep(30)
                    continue
                elif num_of_messages == 1:
                    received_message = response.received_messages[0]
                    yield received_message.message.data.decode("utf-8")
                    self.subscriber_client.acknowledge(
                        request={
                            "subscription": self.subscription_path,
                            "ack_ids": [received_message.ack_id],
                        }
                    )
                    break
                else:
                    raise LogicalInconsistency(
                        "Max message is 1. More messages retrieved..."
                    )
            except Exception as e:
                logger.error(f"Got error while processing the the message {e}")
                raise e
