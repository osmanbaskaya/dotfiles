import logging
import os

from fastapi import Body, FastAPI

from eksi_crawler.config import settings
from eksi_crawler.publisher import PubSubPublisher
from eksi_crawler.utils import configure_logger


configure_logger()

logger = logging.getLogger(__name__)

app = FastAPI()

MAX_NUM_OF_TRY = 3


class EntryIdPublisherManager:
    FUTURES = {}

    def __init__(self):
        self.publisher = PubSubPublisher(
            settings.PROJECT_ID, settings.PUBLISHER_SERVICE_TOPIC_ID
        )
        self.futures = {}
        self.last_published_message = None

    def get_callback(self, message):
        def callback(future):
            num_try = self.futures.pop(message)
            try:
                result = future.result()
                self.last_published_message = message
                logger.debug(f"Message='{message}' is published with Receipt={result}")
            except:  # noqa
                if num_try == 0:
                    logger.warning(f"Maximum number of try exceeded for {message}")
                else:
                    logger.warning(
                        f"Got error for Message='{message}'... Going to try {num_try} "
                        "more times"
                    )
                    self._publish_one_message(message, num_try - 1)

        return callback

    def _publish_one_message(self, message, num_try=MAX_NUM_OF_TRY):
        future = self.publisher.publish(message)
        self.futures[message] = num_try - 1
        # Publish failures shall be handled in the callback function.
        future.add_done_callback(self.get_callback(message))

    def start_publishing(self, start_index, end_index, batch_size):

        for start_index in range(start_index, end_index, batch_size):
            message = f"{start_index} {start_index + batch_size}"
            self._publish_one_message(message)


manager = EntryIdPublisherManager()


@app.put("/Publish")
async def publish_entry_ids(
    start_index: int = Body(...),
    end_index: int = Body(...),
    batch_size: int = Body(settings.PUBLISHER_SERVICE_BATCH_SIZE),
):
    manager.start_publishing(start_index, end_index, batch_size)
    return {"message": "Publishing started for {start_index}, {end_index}"}


@app.get("/NumOfUnpublishedMessages")
async def get_size_of_unpublished_messages():
    return {"num_of_unpublished_message": len(manager.FUTURES)}


@app.get("/LastProcessedMessage")
async def get_last_published_message():
    return {"last_published": manager.last_published_message}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "eksi_crawler.publishing.entry_id_publisher_app:app", debug=False, reload=True
    )
