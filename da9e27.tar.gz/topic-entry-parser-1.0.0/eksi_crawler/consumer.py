import logging
import time

from eksi_crawler.message_handler import SyncMessageHandler
from eksi_crawler.utils import configure_logger, publish_unprocessed_paths

configure_logger()

logger = logging.getLogger(__name__)


class EntryNotFoundException:
    pass


class EntryNotFetchedException:
    pass


class Consumer:
    def __init__(
        self,
        fn,
        project,
        subscription_id=None,
        topic_id=None,
        create_if_not_exist=False,
    ):
        if subscription_id is None:
            raise ValueError("Subscription ID cannot be None.")

        self.project = project
        self.message_handler = SyncMessageHandler(
            project, subscription_id, topic_id, create_if_not_exist
        )

        self.consumer_fn = fn

    def process_message(self, message):
        raise NotImplementedError

    def consume(self):
        logger.info(
            f"Listening for messages on {self.message_handler.subscription_path}"
        )
        while True:
            try:
                with self.message_handler.get_message() as message:
                    logger.info(message)
                    self.process_message(message)
            except KeyboardInterrupt:
                self.message_handler.close()
                logger.info("KeyboardInterrupt. Gracefully shutting down.")
                break


class EksiIdConsumer(Consumer):
    def process_message(self, message):
        ids = [int(entry_id) for entry_id in message.split()]
        if len(ids) != 2:
            logger.warning(
                "Message should have two integer: 'start end'. Deleting the message..."
            )
            return

        start, end = ids
        start_time = time.perf_counter()
        total_num_of_entries, total_num_of_topic_paths, topic_paths = self.consumer_fn(
            range(start, end)
        )
        message = (
            f"{total_num_of_entries} entries and {total_num_of_topic_paths} "
            f"topic paths published from {len(topic_paths)} topics for in {start}, {end}"
            f"in {(time.perf_counter() - start_time):.2f} seconds."
        )
        logger.info(message)


class EksiTopicPathConsumer(Consumer):
    def process_message(self, message):
        paths = [path for path in message.split()]
        (total_num_of_entries, zero_entry_topics, topic_paths) = self.consumer_fn(paths)
        msg = (
            f"{total_num_of_entries} entries from {len(topic_paths)} topic "
            f"paths are published for {len(paths)} initial paths. Zero-entry "
            f"topics: "
            f"{len(zero_entry_topics)}."
        )
        logger.info(msg)
