import logging

import redis

from eksi_crawler.utils import configure_logger

configure_logger()
logger = logging.getLogger(__name__)

ENTRY_PREFIX = "ENTRY__"
TOPIC_PREFIX = "TOPIC__"


class DictCache:
    def __init__(self):
        self.db = {}

    def add_to_cache(self, d: dict):
        self.db.update(d)

    def is_in_cache(self, key):
        return key in self.db

    def get_total_num_of_items(self):
        return len(self.db)

    def nuke(self):
        self.db.clear()


class RedisCache:
    def __init__(self, host="localhost", port="6379", db=0):
        self._redis_client = redis.Redis(host=host, port=port, db=db)

    def add_to_cache(self, d: dict):
        self._redis_client.mset(d)

    def is_in_cache(self, key):
        return bool(self._redis_client.exists(key))

    def get_last_save(self):
        return self._redis_client.lastsave()

    def save(self):
        return self._redis_client.bgsave()

    def get_total_num_of_items(self):
        return self._redis_client.dbsize()

    def nuke(self):
        self._redis_client.flushall()


class EntryTopicCache:
    FIX_VALUE = 0

    def __init__(self):
        self.caches = None

    @staticmethod
    def check_valid(keys):
        if not isinstance(keys, list):
            raise TypeError(f"This is not a list! Got {type(keys)}")

    @staticmethod
    def create_entry_key(entry_id):
        return f"{ENTRY_PREFIX}{entry_id}"

    @staticmethod
    def create_topic_key(topic):
        return f"{TOPIC_PREFIX}{topic}"

    def add_multiple_entries_to_cache(self, entries):
        self.check_valid(entries)
        d = {
            EntryTopicCache.create_entry_key(entry): EntryTopicCache.FIX_VALUE
            for entry in entries
        }
        self.caches["entry_cache"].add_to_cache(d)

    def add_multiple_topic_to_cache(self, topics):
        self.check_valid(topics)
        d = {
            EntryTopicCache.create_topic_key(topic): EntryTopicCache.FIX_VALUE
            for topic in topics
        }
        self.caches["topic_cache"].add_to_cache(d)

    def is_entry_in_cache(self, entry_id):
        key = self.create_entry_key(entry_id)
        return self.caches["entry_cache"].is_in_cache(key)

    def is_topic_in_cache(self, topic):
        key = self.create_topic_key(topic)
        return self.caches["topic_cache"].is_in_cache(key)

    def get_total_num_of_items(self):
        return [c.get_total_num_of_items() for c in self.caches.values()]

    def save(self):
        self.caches["entry_cache"].save()  # one save is enough.

    def get_last_save(self):
        return [c.get_last_save() for c in self.caches.values()]

    def nuke(self):
        return self.caches["entry_cache"].nuke()


class RedisBasedEntryTopicCache(EntryTopicCache):
    def __init__(self, host="localhost", port="6379"):
        self.caches = {
            "entry_cache": RedisCache(host, port, db=0),
            "topic_cache": RedisCache(host, port, db=1),
        }


class DictBasedEntryTopicCache(EntryTopicCache):
    def __init__(self):
        self.caches = {"entry_cache": DictCache(), "topic_cache": DictCache()}
