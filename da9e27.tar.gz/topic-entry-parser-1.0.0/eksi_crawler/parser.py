from enum import Enum
import logging

from bs4 import BeautifulSoup

from eksi_crawler.clients.eksi_client import EksiClient, EksiSozlukPageNotFoundException
from eksi_crawler.utils import configure_logger, convert_date

configure_logger()

logger = logging.getLogger(__name__)


class FetchStatus(Enum):
    COMPLETED = "completed"
    NOT_PROCESSED = "not-processed"


class ElementNotFoundException(Exception):
    pass


class EksiParser:
    def __init__(self, eksi_client=None):
        self.eksi_client = eksi_client or EksiClient()

    def get_all_pages_to_be_fetched(self, entry_soup):
        topic_path = self.get_topic_path(entry_soup)
        try:
            topic_soup = self.get_topic_soup(topic_path)
        except EksiSozlukPageNotFoundException:
            return topic_path, [], [], FetchStatus.NOT_PROCESSED

        last_page_number = self.get_last_page_number(topic_soup)
        # In case there is redirection.
        topic_path = self.get_topic_path(topic_soup)
        entries = self.parse_page_from_soup(topic_soup)
        return (
            topic_path,
            entries,
            (
                topic_path + f"?p={page_id}"
                for page_id in range(2, last_page_number + 1)
            ),
            FetchStatus.COMPLETED,
        )

    def get_topic_soup(self, topic_path):
        page_content = self.eksi_client.fetch_topic(topic_path)
        return BeautifulSoup(page_content, features="html.parser")

    def parse_page(self, topic_path):
        try:
            topic_soup = self.get_topic_soup(topic_path)
        except EksiSozlukPageNotFoundException:
            return []
        return self.parse_page_from_soup(topic_soup)

    def parse_page_from_soup(self, topic_soup):
        topic = self.get_topic(topic_soup)
        topic_path = self.get_topic_path(topic_soup)
        entries_soup = topic_soup.find_all("li", {"data-isfavorite": "false"})
        entries = []
        for entry_soup in entries_soup:
            entry = self.parse_entry(entry_soup)
            if entry is not None:
                entry["topic"] = topic
                entry["topic-path"] = topic_path  # remove the trailing slash
                entries.append(entry)
        return entries

    def get_last_page_number(self, soup):
        div = soup.find("div", {"class": "pager"})
        if div is None:
            return 1
        return int(div["data-pagecount"])

    def parse_entry(self, soup):
        # If text is not there, nothing is there ;)
        try:
            original_text, formatted_text = self.get_text(soup)
        except ElementNotFoundException:
            return None

        create_date, update_date = self.get_dates(soup)

        result = {
            "id": self.get_entry_id(soup),
            "original-text": original_text,
            "formatted-text": formatted_text,
            "author": self.get_author(soup),
            "author-id": self.get_data_author_id(soup),
            "seyler-slug": self.get_seyler_slug(soup),
            "create-date": create_date,
            "update-date": update_date,
        }
        return result

    def get_text(self, soup):
        div = soup.find("div", {"class": "content"})
        if div is not None:
            return [str(e) for e in div.contents], div.text.strip()
        else:
            raise ElementNotFoundException

    def get_author(self, soup):
        author = soup["data-author"]
        return author

    def get_entry_id(self, soup):
        return int(soup["data-id"])

    def get_data_author_id(self, soup):
        return soup["data-author-id"]

    def get_seyler_slug(self, soup):
        return soup["data-seyler-slug"]

    def get_topic_path(self, soup):
        return soup.h1.a["href"][1:]

    def get_topic(self, soup):
        return soup.h1["data-title"]

    def get_dates(self, soup):
        all_dates = soup.find("a", {"class": "entry-date permalink"}).text.split("~")
        create_date = convert_date(all_dates[0])
        update_date = None
        if len(all_dates) == 2:
            update_date = all_dates[-1]
            if len(update_date) == 6:
                # this is same day edit
                update_date = all_dates[0][:10] + update_date
            update_date = convert_date(update_date)

        return create_date, update_date
