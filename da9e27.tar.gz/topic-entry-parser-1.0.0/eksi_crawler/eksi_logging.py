import json
import logging

import google.cloud.logging
from google.cloud.logging.handlers import CloudLoggingHandler
from pythonjsonlogger.jsonlogger import JsonFormatter
from structlog import wrap_logger
from structlog.dev import set_exc_info
from structlog.processors import StackInfoRenderer, TimeStamper, format_exc_info


class GCPHandler(CloudLoggingHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._formatter = JsonFormatter()

    def emit(self, record):
        message = json.loads(self._formatter.format(record))
        self.transport.send(record, message, resource=self.resource, labels=self.labels)


def google_logger_flatter(logger, name, event_dict):
    event_dict.update(event_dict.pop("event", {}))
    return {"msg": event_dict}


client = google.cloud.logging.Client()
handler = GCPHandler(client, name="my-log")
cloud_logger = logging.getLogger("cloudLogger")
cloud_logger.setLevel(logging.INFO)
cloud_logger.addHandler(handler)

log = wrap_logger(
    cloud_logger,
    processors=[
        StackInfoRenderer(),
        set_exc_info,
        format_exc_info,
        TimeStamper(fmt="%Y-%m-%d %H:%M.%S", utc=False),
        google_logger_flatter,
    ],
)
# log._processors = log._processors[:-1]
log = log.bind(debug_id=5)
log.error(message="1")

# cloud_logger.error({"My-id": "5", "message": "hede"})
