import os
from argparse import ArgumentParser
import subprocess

from infra.constants import PREFIX
from infra.constants import REGIONS_ZONES

NUMBER_OF_INSTANCE = 1

COMMAND = (
    "gcloud functions deploy {} --region {} "
    "--runtime=python38 --memory 256MB --service-account "
    "hardy-nation-291804@appspot.gserviceaccount.com --source "
    "https://source.developers.google.com/projects/hardy-nation-291804/repos"
    "/github_imagination-ai_eksi-crawler/moveable-aliases/main/paths"
    "/cloud_functions/crawl_parse_persist --entry-point topic_page_download "
    "--max-instances {} --trigger-topic {} --timeout 540s "
)


def deploy(args):
    command = COMMAND
    if args.env_vars is not None:
        command += "--set-env-vars {} ".format(args.env_vars)

    command += "&"

    total_regions = len(REGIONS_ZONES)
    for i, (region, region_name) in enumerate(REGIONS_ZONES, 1):
        func_name = f"topic-page-consumer-{region_name}"
        c = command.format(
            func_name, region, NUMBER_OF_INSTANCE, f"{PREFIX}-{region_name}"
        )
        print(f"Cloud Function {i}/{total_regions} - {func_name} is being created...")
        if not args.dry_run:
            os.system(c)


def delete(args):
    output = subprocess.check_output("gcloud functions list", shell=True)
    print(output.decode("utf8"))

    if not args.dry_run:
        command = "gcloud functions delete -q {} --region {} &"
        for i, (region, region_name) in enumerate(REGIONS_ZONES, 1):
            os.system(command.format(f"topic-page-consumer-{region_name}", region))


def deploy_unprocessed_data_function():
    command = COMMAND
    command = command.format(
        "unprocessed-pages", "us-central1", 1, "unprocessed-page-paths"
    )


def run():
    parser = ArgumentParser()
    subparsers = parser.add_subparsers(help="sub-command help", dest="action")

    deploy_subparser = subparsers.add_parser("deploy")
    deploy_subparser.add_argument("--env-vars", default=None, required=False)
    deploy_subparser.add_argument("-n", "--dry-run", default=False, action="store_true")

    delete_subparser = subparsers.add_parser("delete")
    delete_subparser.add_argument("-n", "--dry-run", default=False, action="store_true")

    args = parser.parse_args()
    globals()[args.action](args)


if __name__ == "__main__":
    run()
