from google.cloud import pubsub_v1

from infra.constants import PROJECT_ID


def get_topics():

    publisher = pubsub_v1.PublisherClient()
    project_path = f"projects/{PROJECT_ID}"

    topics = []
    for topic in publisher.list_topics(request={"project": project_path}):
        topics.append(topic.name.split("/")[-1])

    topics = [t for t in topics if t.startswith("eksi-")]
    return topics
