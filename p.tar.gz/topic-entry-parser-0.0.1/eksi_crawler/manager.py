from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime
import json
import logging
import os

from bs4 import BeautifulSoup
from google.cloud import storage

from eksi_crawler.clients.cache_client import EksiCacheClient, EksiCacheClientException
from eksi_crawler.clients.eksi_client import EksiClient, EksiSozlukPageNotFoundException
from eksi_crawler.constants import PROJECT_ID
from eksi_crawler.parser import EksiParser, FetchStatus
from eksi_crawler.publisher import EksiPagePathMultipleTopicRandomPublisher
from eksi_crawler.utils import (
    configure_logger,
    create_unique_fn_name,
    get_pubsub_topics,
)

PROJECT_BUCKET_NAME = "eksi"
BATCH_SIZE = int(os.getenv("BATCH_SIZE", 100))
CACHE_MANAGER_HOST = os.getenv("CACHE_MANAGER_HOST", "localhost")
CACHE_MANAGER_PORT = os.getenv("CACHE_MANAGER_PORT", "8000")

configure_logger()

logger = logging.getLogger(__name__)


class LogicalInconsistencyError(Exception):
    pass


class EksiParserManager:
    def __init__(
        self,
        parser=None,
        cache_manager=None,
        eksi_client=None,
        storage_client=None,
        pubsub_client=None,
    ):
        self.parser = parser or EksiParser()
        self.cache_client = cache_manager or EksiCacheClient(
            host=CACHE_MANAGER_HOST, port=CACHE_MANAGER_PORT
        )
        self.eksi_client = eksi_client or EksiClient()
        self.storage_client = storage_client or storage.Client()
        self.pubsub_client = pubsub_client or EksiPagePathMultipleTopicRandomPublisher(
            PROJECT_ID, topics=get_pubsub_topics()[:3]
        )

    def is_in_cache(self, entry_id):
        try:
            return self.cache_client.is_in_cache(entry_id)
        except EksiCacheClientException as e:
            logger.warning(f"CacheManager -- {e}")
            return False

    def transform_to_soup(self, entry_id):
        soup = None
        is_deleted = False
        if not self.is_in_cache(entry_id):
            try:
                html = self.eksi_client.fetch_entry(entry_id)
            except EksiSozlukPageNotFoundException:
                soup = None
                is_deleted = True
            else:
                soup = BeautifulSoup(html, features="html.parser")

        return entry_id, soup, is_deleted

    def collect_first_page_entries_and_get_topic_paths(self, entry_soups, persist):
        # Role #3

        # Persist entries to bucket.
        # Add entries to cache.
        # Publish topic_paths to queues.
        # Add Topic to cache
        entries = []
        all_pages_to_be_fetched = []
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = [
                executor.submit(self.parser.get_all_pages_to_be_fetched, entry_soup)
                for entry_soup in entry_soups
            ]

            for future in as_completed(futures):
                topic_path, entries_for_one_soup, pages_to_be_fetched, status = (
                    future.result()
                )
                if status == FetchStatus.COMPLETED:
                    all_pages_to_be_fetched.append(pages_to_be_fetched)
                    entries.extend(entries_for_one_soup)
                elif status == FetchStatus.NOT_PROCESSED:
                    # TODO: Put this topic_path to unprocessed_queue.
                    logger.warning(f"{topic_path} could not be fetched.")
                else:
                    logger.error(
                        f"LogicalInconsistency for {topic_path}... Code needs to be "
                        f"fixed."
                    )
                    raise LogicalInconsistencyError

        self.persist(entries, persist)

        paths = [
            topic_path
            for topic_path_gen in all_pages_to_be_fetched
            for topic_path in topic_path_gen
        ]
        for i in range(0, len(paths), BATCH_SIZE):
            message = " ".join(paths[i : i + BATCH_SIZE])
            self.pubsub_client.publish(message)

        return len(entries), len(paths)

    def persist(self, entries, persist=True, resource_name=None):
        if len(entries) > 0:
            if persist:
                filename = f"topics/{create_unique_fn_name()}.json"
                self.write_to_bucket(entries, filename)

        try:
            self.cache_client.add_to_cache(
                entry_ids=[e["id"] for e in entries], source=resource_name
            )
        except EksiCacheClientException as e:
            logger.warning(
                f"Cache Manager error @ {CACHE_MANAGER_HOST}:{CACHE_MANAGER_PORT} "
                f"with {e}"
            )

    def collect_entries_from_topic_path(self, topic_paths, persist, resource_name):
        # Role #4
        # Fetch entries
        # Persist entries to bucket
        # Add entries to cache.
        entries = []
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(self.parser.parse_topic_page, topic_paths)]
            for future in as_completed(futures):
                entries.extend(future.result())

        total_num_of_entries = len(entries)
        self.persist(entries)
        return total_num_of_entries

    def get_soups(self, entry_ids, persist=True):
        entry_ids_with_soups = []
        deleted_entries = []
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = [
                executor.submit(self.transform_to_soup, entry_id)
                for entry_id in entry_ids
            ]
            for future in as_completed(futures):
                entry_id, soup, is_deleted = future.result()
                if soup is not None:
                    entry_ids_with_soups.append((entry_id, soup))
                else:
                    if is_deleted:
                        deleted_entries.append(str(entry_id))
        if len(deleted_entries) > 0:
            if persist:
                self.write_to_bucket(
                    "\n".join(deleted_entries),
                    f"deleted-entries/{datetime.datetime.now().isoformat()}",
                    jsonize=False,
                )
        return entry_ids_with_soups

    def write_to_bucket(self, obj, destination_blob_name, jsonize=True):
        if jsonize:
            obj = json.dumps(obj)
        bucket = self.storage_client.bucket(PROJECT_BUCKET_NAME)
        blob = bucket.blob(destination_blob_name)
        blob.upload_from_string(obj)
        print(f"Written to gs://{PROJECT_BUCKET_NAME}/{destination_blob_name}")


manager = EksiParserManager()


def _crawl_parse_persist(entry_ids, persist=True, resource_name=None):
    entries_to_fetch = []

    topic_paths = set()

    entry_ids_with_soups = [
        e for e in manager.get_soups(entry_ids, persist) if e[1] is not None
    ]
    # Let's remove entries that their topics are the same.
    for entry_id, soup in entry_ids_with_soups:
        topic_path = manager.parser.get_topic_path(soup)
        if topic_path not in topic_paths:
            # Check Cache to make sure these topic_paths are not already fetched.
            if not manager.is_in_cache(topic_path):
                entries_to_fetch.append((entry_id, soup))
                topic_paths.add(topic_path)

    entry_ids, soups = zip(*entries_to_fetch)
    print(f"Followings are the topics that will be fetched: {topic_paths}")
    total_num_of_entries, total_num_of_topic_path = manager.collect_first_page_entries_and_get_topic_paths(
        soups, persist
    )

    print(
        f"{total_num_of_entries} entries persisted and {total_num_of_topic_path} topic "
        f"paths published..."
    )


_crawl_parse_persist([2, 3, 6, 555])
