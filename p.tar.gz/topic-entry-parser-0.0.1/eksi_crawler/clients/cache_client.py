import json
import os

from eksi_crawler.clients.base_http_client import BaseHttpClient
from eksi_crawler.clients.base_http_client import HTTPClientException


class EksiCacheClientException(HTTPClientException):
    pass


class EksiCacheClient(BaseHttpClient):
    def add_to_cache(self, entry_ids, source=None):
        url = self.base_url + "/Entry"
        data = json.dumps(
            {"entry_ids": entry_ids, "source": source}
        )
        return self.do_request(
            "PUT",
            url,
            operation_name="add-to-cache",
            client_exception_class=EksiCacheClientException,
            data=data,
        )

    def is_in_cache(self, entry_id):
        url = self.base_url + f"/Entry/{entry_id}"
        return self.do_request(
            "GET",
            url,
            operation_name="get-entry",
            client_exception_class=EksiCacheClientException,
        )


if __name__ == "__main__":
    CACHE_MANAGER_HOST = os.getenv("CACHE_MANAGER_HOST", "35.238.217.161")
    CACHE_MANAGER_PORT = os.getenv("CACHE_MANAGER_PORT", "80")

    client = EksiCacheClient(host=CACHE_MANAGER_HOST, port=CACHE_MANAGER_PORT)

    print(client.add_to_cache(5, [1, 2, 3], source="amsterdam"))
