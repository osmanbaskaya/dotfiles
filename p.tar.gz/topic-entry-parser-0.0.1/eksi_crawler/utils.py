import datetime
import logging
from uuid import uuid4

from eksi_crawler.constants import REGIONS_ZONES, TOPIC_PREFIX

logger = logging.getLogger(__name__)


def configure_logger():
    # set up logging to file
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s] {%(pathname)s:%(lineno)d} %(levelname)s - %(message)s",
        datefmt="%H:%M:%S",
    )

    # set up logging to console
    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG)
    # set a format which is simpler for console use
    formatter = logging.Formatter("%(name)-12s: %(levelname)-8s %(message)s")
    console.setFormatter(formatter)
    # add the handler to the root logger
    logging.getLogger("").addHandler(console)


def convert_date(date: str):
    date = date.strip()
    if len(date) == 10:
        date_format = "%d.%m.%Y"
    else:
        date_format = "%d.%m.%Y %H:%M"
    date = (
        datetime.datetime.strptime(date, date_format) + datetime.timedelta(hours=-3)
    ).replace(tzinfo=datetime.timezone.utc)

    return date.isoformat()


def create_unique_fn_name():
    return f"{datetime.datetime.now().isoformat()}-{uuid4().hex[:5]}"


def get_pubsub_topics():
    return [f"{TOPIC_PREFIX}-{zone}" for _, zone in REGIONS_ZONES]
