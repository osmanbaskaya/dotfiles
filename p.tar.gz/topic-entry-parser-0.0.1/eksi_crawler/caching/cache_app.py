import logging
import os
from typing import List

from fastapi import Body
from fastapi import FastAPI

from eksi_crawler.caching.manager import EksiIdCacheManager
from eksi_crawler.constants import PROJECT_BUCKET
from eksi_crawler.constants import PROJECT_ID
from eksi_crawler.utils import configure_logger

configure_logger()

BUCKET_SIZE = int(os.getenv("BUCKET_SIZE", 500 * 1000))

CACHE_MANAGER = EksiIdCacheManager(bucket_size=BUCKET_SIZE)
STORAGE_CLIENT = None

logger = logging.getLogger(__name__)

app = FastAPI()


def get_storage_client():
    global STORAGE_CLIENT
    if STORAGE_CLIENT is None:
        try:
            from google.cloud import storage

            STORAGE_CLIENT = storage.Client()
        except Exception:
            return None

    return STORAGE_CLIENT


@app.on_event("shutdown")
def shutdown_event():
    logger.info(
        "Application is going to shutdown. Before fully go offline, cache is going to "
        "be saved "
    )
    dest_filepath = save_cache_manager()
    logger.info(f"Cache is saved to {dest_filepath}")


@app.put("/Entry")
async def add_to_cache(
    root_entry: int = Body(...),
    entry_ids: List[int] = Body(...),
    source: str = Body(...),
):
    for entry_id in entry_ids:
        CACHE_MANAGER.add_to_cache(entry_id)
    CACHE_MANAGER.add_to_cache(root_entry, source)
    logger.info(f"{root_entry} and {entry_ids} are saved to cache.")
    return {"success": True, "message": f"{entry_ids} added"}


@app.post("/Compact")
async def compact():
    CACHE_MANAGER.compact()
    return {"success": True, "message": "Compaction done."}


@app.get("/Entry/{entry_id}")
async def is_in_cache(entry_id: int):
    return entry_id in CACHE_MANAGER


@app.get("/PersistCache")
async def persist_cache():
    fn = save_cache_manager()
    return {"success": True, "message": f"File is saved to {PROJECT_BUCKET}/{fn}"}


@app.get("/Sources")
async def sources():
    return CACHE_MANAGER.sources


def save_cache_manager():
    storage_client = get_storage_client()
    if storage_client is not None:
        BUCKET = get_storage_client().bucket(
            bucket_name=PROJECT_BUCKET, user_project=PROJECT_ID
        )
        CACHE_MANAGER.compact()
        cache_out_fn = CACHE_MANAGER.persist()
        basename = os.path.basename(cache_out_fn)
        destination_blob_name = f"cache_manager_images/{basename}"
        blob = BUCKET.blob(destination_blob_name)
        blob.upload_from_filename(cache_out_fn)
        logger.info(f"Cache is saved to {destination_blob_name}")
        return destination_blob_name
    else:
        return None


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("eksi_crawler.caching.cache_app:app", debug=False, reload=True)
