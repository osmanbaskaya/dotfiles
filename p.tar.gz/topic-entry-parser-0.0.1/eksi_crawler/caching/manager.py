import datetime
import logging
import time
from collections import UserDict
from itertools import islice

import cloudpickle

from eksi_crawler.utils import configure_logger

configure_logger()
logger = logging.getLogger(__name__)


class EksiIdCache(UserDict):
    def compact(self, value):
        """Remove keys smaller than the given `value` and return the count."""
        keys = list(self.data.keys())
        return len([self.data.pop(k) for k in keys if k < value])

    def __repr__(self, n=10):
        elements = list(islice(self.data.keys(), n + 1))
        if len(elements) > n:
            representation = ", ".join(str(i) for i in elements[:n])
            representation = f"[{representation}, ...]"
        else:
            representation = ", ".join(str(i) for i in elements)
            representation = f"[{representation}]"
        return representation

    def __getstate__(self):
        return None, {"data": self.data}


class EksiIdCacheManager(UserDict):
    def __init__(self, *, cache=None, bucket_size=None, **kwargs):
        super().__init__(**kwargs)
        if cache is not None and bucket_size is not None:
            raise ValueError("If cache param is provided, batch size should be None")
        self._cache = cache or {}
        self.bucket_size = bucket_size or 500 * 1000  # Default bucket size 500k
        self.sources = {}

    def __getitem__(self, key: int):
        raise TypeError("Cache Manager doesn't support get")

    def __setitem__(self, key: int, value):
        bucket = self._get_bucket(key)
        if bucket not in self._cache:
            self._cache[bucket] = EksiIdCache()
        self._cache[bucket][key] = None

    def __contains__(self, key: int):
        bucket = self._get_bucket(key)
        return bucket in self._cache and key in self._cache[bucket]

    def __len__(self):
        return len(self._cache)

    def size(self):
        return sum(map(len, self._cache.values()))

    def add_to_cache(self, key, source=None):
        self[key] = None
        if source is not None:
            self.sources[source] = key

    @classmethod
    def load_from_disk(cls, cache_dir):
        pass

    def _get_bucket(self, key: int):
        return key // self.bucket_size

    def compact(self, entry_id=None):
        last_cached_entry = entry_id or min(self.sources.values())
        start_time = time.perf_counter()

        logger.info(f"Compaction started with last_cached_entry={last_cached_entry}")

        num_of_caches = len(self._cache)

        bucket = self._get_bucket(last_cached_entry)

        # Since cache buckets are ordered we can completely remove the ones that are
        # smaller than the `bucket`
        buckets_to_remove = [b for b in range(bucket) if b in self._cache]
        total_num_of_removed_keys = sum(
            len(self._cache.pop(b)) for b in buckets_to_remove
        )
        if total_num_of_removed_keys != 0:
            logger.info(f"Buckets {buckets_to_remove} removed completely.")

        # Now we can partially clean the bucket where last_cached_entry lives
        if bucket in self._cache:
            total_num_of_removed_keys += self._cache[bucket].compact(last_cached_entry)
        total_time = time.perf_counter() - start_time
        logger.info(
            f"Compaction ended... Total {total_num_of_removed_keys} entries pruned "
            f"from {num_of_caches} caches. It took {total_time} seconds."
        )

    def __getstate__(self):
        return {"_cache": self._cache, "bucket_size": self.bucket_size}

    def __setstate__(self, state):
        self.__dict__.update(**state)
        self.sources = {}

    def persist(self):
        fn = f"/tmp/cache-{datetime.datetime.now().isoformat()}.pkl"
        with open(fn, "wb") as f:
            cloudpickle.dump(self, f)
        logger.info(f"Persisting the cache to {fn}")
        return fn

    def __del__(self):
        output_fn = self.persist()
        logger.info(f"CacheManager is persisted to {output_fn}")
        del self

    def __repr__(self):
        return self._cache.__repr__()
