import asyncio
from itertools import cycle

from infra.utils import get_topics

# TODO argparse this.
batch_size = 100
starting_id = 253001
ending_id = 500001


async def run_command_shell(command):
    """Run command in subprocess (shell).

    Note:
        This can be used if you wish to execute e.g. "copy"
        on Windows, which can only be executed in the shell.
    """
    # Create subprocess
    process = await asyncio.create_subprocess_shell(
        command, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )

    # Status
    # print("Started:", command, "(pid = " + str(process.pid) + ")", flush=True)

    # Wait for the subprocess to finish
    stdout, stderr = await process.communicate()

    # Progress
    # if process.returncode == 0:
    #     print("Done:", command, "(pid = " + str(process.pid) + ")", flush=True)
    # else:
    #     print("Failed:", command, "(pid = " + str(process.pid) + ")", flush=True)

    # Result
    result = stdout.decode().strip()

    # Return stdout
    return result


async def worker(queue):
    while True:
        command = await queue.get()
        result = await run_command_shell(command)
        print(command, result.replace("\n", " "))
        queue.task_done()


async def publish_messages():
    queue = asyncio.Queue()

    topics = get_topics()
    print(topics)
    print(f"Total num of topics {len(topics)}")

    topics_iter = cycle(topics)

    for start in range(starting_id, ending_id, batch_size):
        end = start + batch_size
        batch = " ".join(str(i) for i in range(start, end))
        command = (
            f"gcloud pubsub topics publish {next(topics_iter)} --message='{batch}'"
        )
        queue.put_nowait(command)

    consumers = []
    for i in range(25):
        consumer = asyncio.create_task(worker(queue))
        consumers.append(consumer)

    await queue.join()
    for c in consumers:
        c.cancel()


if __name__ == "__main__":
    try:
        asyncio.run(publish_messages())
    except KeyboardInterrupt:
        print("stopping...")
