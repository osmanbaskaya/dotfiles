import os

from infra.constants import PREFIX
from infra.constants import REGIONS_ZONES


def create_topics(prefix=PREFIX):
    for region, region_name in REGIONS_ZONES:
        command = f"gcloud pubsub topics create {prefix}-{region_name}"
        try:
            os.system(command)
        except Exception:
            pass


create_topics()
