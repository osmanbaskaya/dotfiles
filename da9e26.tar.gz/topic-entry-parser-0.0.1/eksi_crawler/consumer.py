from concurrent.futures import TimeoutError
from functools import partial
import logging

from google.cloud import pubsub_v1

from eksi_crawler.utils import configure_logger

configure_logger()

logger = logging.getLogger(__name__)


class EntryNotFoundException:
    pass


class EntryNotFetchedException:
    pass


class Consumer:
    def __init__(
        self, project, subscription_id=None, topic_id=None, create_if_not_exist=False
    ):
        if subscription_id is None:
            raise ValueError("Subscription ID cannot be None.")

        self.project = project
        self.subscriber_client = pubsub_v1.SubscriberClient()

        self.subscription_id = subscription_id

        self.subscription_path = self.subscriber_client.subscription_path(
            self.project, self.subscription_id
        )
        if create_if_not_exist:
            self._create_subscription_if_not_exist(topic_id)

        self.consumer_fn = None

    def set_consumer_fn(self, consumer_fn, **kwargs):
        self.consumer_fn = partial(consumer_fn, **kwargs)

    def _create_subscription_if_not_exist(self, topic_id):
        subscription_ids = set()
        for subscription in self.subscriber_client.list_subscriptions(
            request={"project": f"projects/{self.project}"}
        ):
            subscription_ids.add(subscription.name.rsplit("/")[-1])

        if self.subscription_id not in subscription_ids:
            self._create_subscription(topic_id)

    def _create_subscription(self, topic_id):
        publisher = pubsub_v1.PublisherClient()
        logger.info(f"Creating a subscription on {topic_id} first.")
        topic_path = publisher.topic_path(self.project, topic_id)

        r = self.subscriber_client.create_subscription(
            request={"name": self.subscription_path, "topic": topic_path}
        )

        logger.info(r)

    def process_message(self, message):
        data = message.data.decode("utf-8")
        self.consumer_fn(data)
        message.ack()

    def consume(self, max_messages_in_flow=1):
        if self.consumer_fn is None:
            raise ValueError(
                "consumer_fn should be set before consume call. Use set_consumer_fn "
                "method"
            )
        while True:
            flow_control = pubsub_v1.types.FlowControl(
                max_messages=max_messages_in_flow
            )
            streaming_pull_future = self.subscriber_client.subscribe(
                self.subscription_path,
                callback=self.process_message,
                flow_control=flow_control,
            )
            try:
                logger.info(f"Listening for messages on {self.subscription_path}")
                streaming_pull_future.result()
            except TimeoutError:
                pass
            except Exception as e:
                logger.error(f"Got error while processing the the message {e}")
            except KeyboardInterrupt:
                streaming_pull_future.cancel()
                self.subscriber_client.close()
                logger.info("Consumer will stop gracefully.")
                break


class EksiIdConsumer(Consumer):
    def process_message(self, message):
        data = message.data.decode("utf-8")
        ids = [int(entry_id) for entry_id in data.split()]
        if len(ids) != 2:
            logger.warning(
                "Message should have two integer: 'start end'. Deleting the message..."
            )
            message.ack()

        start, end = ids
        logger.info(
            f"Message is fetched for entries [{start}, {end}). First page processing "
            "started. Entries will be downloaded and remaining pages will be published."
        )
        self.consumer_fn(range(start, end))
        message.ack()
