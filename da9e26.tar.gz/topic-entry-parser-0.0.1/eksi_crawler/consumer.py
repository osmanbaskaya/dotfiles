import logging
from concurrent.futures import TimeoutError

from google.cloud import pubsub_v1

from eksi_crawler.parser import fetch_entry
from eksi_crawler.parser import EksiParser

logger = logging.getLogger(__name__)


class EntryNotFoundException:
    pass


class EntryNotFetchedException:
    pass


class PubSubConsumer:
    def __init__(
        self,
        project,
        subscription_id,
    ):
        self.project = project
        self.subscription_id = subscription_id

        self.subscriber_client = pubsub_v1.SubscriberClient()
        self.subscription_path = self.subscriber_client.subscription_path(
            self.project, self.subscription_id
        )
        self.entry_parser = EksiParser()

    def _process_message(self, message):
        entry_id = message.data.decode("utf-8")
        entry = fetch_entry(entry_id, self.entry_parser)  # noqa F841
        # TODO persist into a bucket
        message.ack()

    def consume(self, timeout=10):
        streaming_pull_future = self.subscriber_client.subscribe(
            self.subscription_path, callback=self._process_message
        )
        logger.info(f"Listening for messages on {self.subscription_path}")

        with self.subscriber_client:
            try:
                # When `timeout` is not set, result() will block indefinitely,
                # unless an exception is encountered first.
                streaming_pull_future.result(timeout=timeout)
            except TimeoutError:
                streaming_pull_future.cancel()
            except EntryNotFoundException:
                # TODO something meaningful here.
                pass
            except EntryNotFetchedException:
                # TODO this means that they are blocking us. We may introduce
                #  some waiting here.
                pass
            except Exception as e:
                logger.error(f"Got error while processing the the message {e}")
