from typing import List

from pydantic import BaseSettings


class Settings(BaseSettings):
    APP_TYPE = "cache-manager"
    APP_HOST = "0.0.0.0"
    APP_PORT = 80

    PROJECT_BUCKET = "sourtimes"
    PROJECT_ID = "hardy-nation-291804"

    CACHE_SERVICE_HOST = "cache-service"
    CACHE_SERVICE_PORT: int = 8000

    FIRST_PAGE_SERVICE_SUBSCRIPTION_ID: str = "eksi-first-page"
    FIRST_PAGE_SERVICE_PUBLISH_BATCH: int = 100
    FIRST_PAGE_SERVICE_MAX_MESSAGE_IN_FLOW: int = 1

    REDIS_SERVICE_HOST = "redis-service"
    REDIST_SERVICE_PORT: int = 6379

    PUBLISHER_SERVICE_BATCH_SIZE: int = 100
    PUBLISHER_SERVICE_TOPIC_ID: str = "entry-ids"

    ENTRY_IDS_TOPIC_ID: str = "entry-ids"
    PERSIST: bool = True

    UNPROCESSED_TOPIC_PAGES_TOPIC_ID = "unprocessed-page-paths"
    USE_CACHE: bool = True
    TOPIC_PREFIX = "eksi"

    REGIONS_ZONES: List[tuple] = [
        ("us-central1", "iowa"),
        ("us-east1", "south-carolina"),
        ("us-east4", "virginia"),
        ("europe-west1", "belgium"),
        ("europe-west2", "london"),
        ("asia-east2", "hong-kong"),
        ("asia-northeast1", "tokyo"),
        ("asia-northeast2", "osaka"),
        ("europe-west3", "frankfurt"),
        ("europe-west6", "zurich"),
        ("us-west3", "salt-lake-city"),
        ("northamerica-northeast1", "montreal"),
        ("australia-southeast1", "sydney"),
        ("us-west2", "los-angeles"),
        ("us-west4", "las-vegas"),
        ("southamerica-east1", "sao"),
        ("Paulo", "asia-south1"),
        ("mumbai", "asia-southeast2"),
        ("jakarta", "asia-northeast3"),
    ]

    TOPIC_PREFIX_FOR_PAGE_CONSUMER = "eksi"

    class Config:
        case_sensitive = True


settings = Settings()
