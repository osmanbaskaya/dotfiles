import logging

import redis

from eksi_crawler.utils import configure_logger

configure_logger()
logger = logging.getLogger(__name__)


class RedisCache:
    FIX_VALUE = 0

    def __init__(self, host="localhost", port="6379", db=0):
        self._redis_client = redis.Redis(host=host, port=port, db=db)

    def add_to_cache(self, keys):
        d = {key: RedisCache.FIX_VALUE for key in keys}
        self._redis_client.mset(d)

    def is_in_cache(self, key):
        return bool(self._redis_client.exists(key))

    def get_last_save(self):
        return self._redis_client.lastsave()

    def save(self):
        return self._redis_client.save()
