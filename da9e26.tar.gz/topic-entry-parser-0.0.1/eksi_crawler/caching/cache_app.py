import logging
from typing import List, Union

from fastapi import Body, FastAPI

from eksi_crawler.caching.manager import EntryTopicCache
from eksi_crawler.config import settings
from eksi_crawler.utils import configure_logger

configure_logger()


CACHE = EntryTopicCache(
    host=settings.REDIS_SERVICE_HOST, port=settings.REDIST_SERVICE_PORT
)
STORAGE_CLIENT = None

logger = logging.getLogger(__name__)

app = FastAPI()


def get_storage_client():
    global STORAGE_CLIENT
    if STORAGE_CLIENT is None:
        try:
            from google.cloud import storage

            STORAGE_CLIENT = storage.Client()
        except Exception:
            return None

    return STORAGE_CLIENT


@app.put("/Entries")
async def add_multiple_entries_to_cache(entries: List[Union[int, str]] = Body(...)):
    CACHE.add_multiple_entries_to_cache(entries)
    return {"success": True}


@app.put("/Topics")
async def add_multiple_topic_to_cache(topics: List[str] = Body(...)):
    CACHE.add_multiple_topic_to_cache(topics)
    return {"success": True}


@app.get("/Entries/{entry_id}")
async def is_entry_in_cache(entry_id: Union[int, str]):
    return CACHE.is_entry_in_cache(entry_id)


@app.get("/Topics/{topic}")
async def is_topic_in_cache(topic: str):
    return CACHE.is_topic_in_cache(topic)


@app.get("/LastSavedDate")
async def last_saved():
    entry_cache_save, topic_cache_save = CACHE.get_last_save()
    return {
        "message": f"EntryCache: {entry_cache_save}, TopicCache: {topic_cache_save}"
    }


@app.post("/BackgroundSave")
async def bg_save():
    return CACHE.save()


@app.get("/DatabaseStats")
async def get_num_items_in_cache():
    num_entries, num_topics = CACHE.get_total_num_of_items()
    return {"message": f"There are {num_entries} entries, {num_topics} in cache"}


@app.post("/NukeDb")
async def nuke_db(message: str = Body(...)):
    if message == "tabula-rasa":
        return CACHE.nuke()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("eksi_crawler.caching.cache_app:app", debug=False, reload=True)
