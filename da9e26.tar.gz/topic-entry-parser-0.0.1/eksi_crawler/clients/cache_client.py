import json
import os

from eksi_crawler.clients.base_http_client import BaseHttpClient, HTTPClientException


class EksiCacheClientException(HTTPClientException):
    pass


class EksiCacheClient(BaseHttpClient):
    def add_to_cache(self, keys):
        url = self.base_url + "/Keys"
        data = json.dumps(keys)
        return self.do_request(
            "PUT",
            url,
            operation_name="add-to-cache",
            client_exception_class=EksiCacheClientException,
            data=data,
        )

    def is_in_cache(self, key):
        url = self.base_url + f"/Keys/{key}"
        return self.do_request(
            "GET",
            url,
            operation_name="get-entry",
            client_exception_class=EksiCacheClientException,
        )


if __name__ == "__main__":
    CACHE_MANAGER_HOST = os.getenv("CACHE_MANAGER_HOST", "localhost")
    CACHE_MANAGER_PORT = os.getenv("CACHE_MANAGER_PORT", "80")

    client = EksiCacheClient(host=CACHE_MANAGER_HOST, port=CACHE_MANAGER_PORT)

    print(client.add_to_cache([1, 2, 3, 4, 5]))
    print(client.is_in_cache(5))
