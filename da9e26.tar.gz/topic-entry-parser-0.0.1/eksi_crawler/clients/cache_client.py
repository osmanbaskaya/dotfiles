import json
import os

from eksi_crawler.clients.base_http_client import BaseHttpClient, HTTPClientException
from eksi_crawler.config import settings


class EksiCacheClientException(HTTPClientException):
    pass


class EksiCacheClient(BaseHttpClient):
    def add_multiple_entries_to_cache(self, entries):
        url = self.base_url + "/Entries"
        data = json.dumps(entries)
        return self.do_request(
            "PUT",
            url,
            operation_name="add-entries-to-cache",
            client_exception_class=EksiCacheClientException,
            data=data,
        )

    def add_multiple_topic_to_cache(self, topics):
        if not isinstance(topics, list):
            topics = [topics]
        url = self.base_url + "/Topics"
        data = json.dumps(topics)
        return self.do_request(
            "PUT",
            url,
            operation_name="add-topic-to-cache",
            client_exception_class=EksiCacheClientException,
            data=data,
        )

    def is_topic_in_cache(self, key):
        url = self.base_url + f"/Topics/{key}"
        return self._is_in_cache(url)

    def is_entry_in_cache(self, key):
        url = self.base_url + f"/Entries/{key}"
        return self._is_in_cache(url)

    def _is_in_cache(self, url):
        return self.do_request(
            "GET",
            url,
            operation_name="key-is-in-cache",
            client_exception_class=EksiCacheClientException,
        )


if __name__ == "__main__":
    client = EksiCacheClient(
        host=settings.CACHE_SERVICE_HOST, port=settings.CACHE_SERVICE_PORT
    )

    print(client.add_multiple_entries_to_cache([1, 2, 3, 4, 5]))
    assert client.is_entry_in_cache(5)
    assert not client.is_topic_in_cache(5)
    print(client.add_multiple_topic_to_cache(["topic1", "topic2"]))
    assert client.is_topic_in_cache("topic1")
    assert not client.is_topic_in_cache("topic3")
