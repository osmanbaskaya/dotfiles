import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


class HTTPClientException(Exception):
    pass


class BaseHttpClient:
    def __init__(self, host, port):

        if not host.startswith("http://") and not host.startswith("https://"):
            host = "http://" + host
        self.base_url = f"{host}:{port}"

        self.sess = requests.Session()
        retry_strategy = Retry(
            total=5, backoff_factor=0.3, status_forcelist=[502, 503, 504]
        )
        self.sess.mount(
            "http://", HTTPAdapter(pool_connections=10, max_retries=retry_strategy)
        )

    def do_request(
        self,
        method,
        url,
        operation_name,
        headers=None,
        data=None,
        client_exception_class=None,
        jsonify=True,
    ):
        client_exception_class = client_exception_class or HTTPClientException
        if not issubclass(client_exception_class, HTTPClientException):
            raise TypeError(
                "client exception class should be inherited from " "HTTPClientException"
            )
        try:
            resp = self.sess.request(method, url, headers=headers, data=data)
            if int(resp.status_code) // 100 != 2:
                raise client_exception_class(resp)
            elif resp.status_code == 204:
                return resp.text
            if jsonify:
                return resp.json()
            else:
                return resp.text
        except client_exception_class as e:
            raise e
        except Exception as e:
            raise client_exception_class(f"Error in {operation_name}: {e}") from e
