import random

from eksi_crawler.clients.base_http_client import BaseHttpClient
from eksi_crawler.clients.base_http_client import HTTPClientException


class EksiSozlukPageNotFoundException(HTTPClientException):
    pass


AGENTS = [
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 "
    "Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/51.0.2704.106 Safari/537.36 OPR/38.0.2220.41",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/78.0.3904.108 Safari/537.36",
    "Mozilla/5.0 (Windows NT 5.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/60.0.3112.90 Safari/537.36",
    "Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/60.0.3112.90 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_4) AppleWebKit/605.1.15 (KHTML, "
    "like Gecko)",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/79.0.3945.130 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/52.0.2743.116 Safari/537.36 Edge/15.15063",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/85.0.4183.121 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/83.0.4103.116 Safari/537.36",
    "Mozilla/5.0 (Windows NT 5.1; rv:33.0) Gecko/20100101 Firefox/33.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/80.0.3987.132 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/605.1.15 (KHTML, "
    "like Gecko) Version/12.1.1 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/84.0.4147.135 Safari/537.36",
]


def get_agent():
    return random.choice(AGENTS)


class EksiClient(BaseHttpClient):
    ENTRY_URL = "/entry/{}"
    TOPIC_URL = "/{}"

    def __init__(self):
        super().__init__(host="https://eksisozluk.com", port=443)

    def fetch_topic(self, topic_path):
        url = self.base_url + EksiClient.TOPIC_URL.format(topic_path)
        headers = {"User-Agent": get_agent()}
        return self.do_request(
            "GET",
            url,
            operation_name="get-topic",
            headers=headers,
            client_exception_class=EksiSozlukPageNotFoundException,
            jsonify=False,
        )

    def fetch_entry(self, entry_id):
        url = self.base_url + EksiClient.ENTRY_URL.format(entry_id)
        headers = {"User-Agent": get_agent()}
        return self.do_request(
            "GET",
            url,
            operation_name="get-entry",
            headers=headers,
            client_exception_class=EksiSozlukPageNotFoundException,
            jsonify=False,
        )
