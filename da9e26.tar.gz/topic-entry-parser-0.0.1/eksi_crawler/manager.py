from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime
import json
import logging
import time

from bs4 import BeautifulSoup
from google.cloud import storage
import wasabi

from eksi_crawler.clients.cache_client import EksiCacheClient, EksiCacheClientException
from eksi_crawler.clients.eksi_client import EksiClient, EksiSozlukPageNotFoundException
from eksi_crawler.config import settings
from eksi_crawler.parser import EksiParser, FetchStatus
from eksi_crawler.publisher import EksiPagePathMultipleTopicRandomPublisher
from eksi_crawler.utils import (
    configure_logger,
    create_unique_fn_name,
    get_pubsub_topics,
)

configure_logger(filename="manager.log")

logger = logging.getLogger(__name__)


class LogicalInconsistencyError(Exception):
    pass


class EksiParserManager:
    def __init__(
        self,
        parser=None,
        cache_manager=None,
        eksi_client=None,
        storage_client=None,
        persist=True,
        use_cache=True,
    ):
        self.parser = parser or EksiParser()
        self.cache_client = cache_manager or EksiCacheClient(
            host=settings.CACHE_SERVICE_HOST, port=settings.CACHE_SERVICE_PORT
        )
        self.eksi_client = eksi_client or EksiClient()
        self.storage_client = storage_client or storage.Client()
        self.persist = persist
        self.use_cache = use_cache

    def persist_entries(self, entries):
        if self.persist and self.use_cache:
            if len(entries) > 0:
                filename = f"topics/{create_unique_fn_name()}.json"
                self.write_to_bucket(entries, filename)

                try:
                    self.cache_client.add_multiple_entries_to_cache(
                        entries=[e["id"] for e in entries]
                    )
                except EksiCacheClientException as e:
                    logger.warning(
                        f"Cache Manager error @ {settings.CACHE_SERVICE_HOST}:"
                        f"{settings.CACHE_SERVICE_PORT} with {e}"
                    )
        else:
            logger.warning(
                "Persist is disabled... Cache & Bucket updates won't happen."
            )

    def persist_topics(self, topics):
        if self.persist and self.use_cache:
            if len(topics) > 0:
                try:
                    # remove the slash at the beginning.
                    self.cache_client.add_multiple_topic_to_cache(
                        topics=[t for t in topics]
                    )
                except EksiCacheClientException as e:
                    logger.warning(
                        f"Cache Manager error @ {settings.CACHE_SERVICE_HOST}:"
                        f"{settings.CACHE_SERVICE_PORT} with {e}"
                    )

    def write_to_bucket(self, obj, destination_blob_name, jsonize=True):
        if jsonize:
            obj = json.dumps(obj)
        bucket = self.storage_client.bucket(settings.PROJECT_BUCKET)
        blob = bucket.blob(destination_blob_name)
        blob.upload_from_string(obj)
        logger.info(
            f"Written to gs://{settings.PROJECT_BUCKET}/{destination_blob_name}"
        )


class FirstPageParserManager(EksiParserManager):
    """Objects of this class does the following:

    - Get the message from a specific topic. This message contains entry ids.
    - All entries that are not in the cache will be downloaded. Topic of each entry
        will be collected. Topics are not already observed and persisted into cache
        will be considered for further processing.
    - First page of each topic will be fetched and persisted into Cloud Storage.
    - The link of the each topic's remaining pages will be sent via PubSub randomly
      to each topics.

    Reference: Role #3.
    """

    def __init__(
        self,
        parser=None,
        cache_manager=None,
        eksi_client=None,
        storage_client=None,
        publisher=None,
        persist=True,
        use_cache=True,
    ):
        super().__init__(
            parser,
            cache_manager,
            eksi_client,
            storage_client,
            persist=persist,
            use_cache=use_cache,
        )
        self.publisher = publisher or EksiPagePathMultipleTopicRandomPublisher(
            settings.PROJECT_ID, topics=get_pubsub_topics()
        )

    def get_soups(self, entry_ids):
        entry_ids_with_soups = []
        deleted_entries = []
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = [
                executor.submit(self.transform_to_soup, entry_id)
                for entry_id in entry_ids
            ]
            for future in as_completed(futures):
                entry_id, soup, is_deleted = future.result()
                if soup is not None:
                    entry_ids_with_soups.append((entry_id, soup))
                else:
                    if is_deleted:
                        deleted_entries.append(str(entry_id))

        if len(deleted_entries) > 0:
            if self.persist:
                logger.debug(f"{len(deleted_entries)} found.")
                self.write_to_bucket(
                    "\n".join(deleted_entries),
                    f"deleted-entries/{datetime.datetime.now().isoformat()}",
                    jsonize=False,
                )
        return entry_ids_with_soups

    def _is_in_cache(self, key, fn):
        if self.use_cache:
            try:
                return fn(key)
            except EksiCacheClientException as e:
                logger.debug(f"CacheManager may not work correctly -- {e}")
                return False
        return False

    def is_topic_in_cache(self, key):
        return self._is_in_cache(key, self.cache_client.is_topic_in_cache)

    def is_entry_in_cache(self, key):
        return self._is_in_cache(key, self.cache_client.is_entry_in_cache)

    def transform_to_soup(self, entry_id):
        soup = None
        is_deleted = False
        if not self.is_entry_in_cache(entry_id):
            try:
                html = self.eksi_client.fetch_entry(entry_id)
            except EksiSozlukPageNotFoundException:
                soup = None
                is_deleted = True
            else:
                soup = BeautifulSoup(html, features="html.parser")

        return entry_id, soup, is_deleted

    def collect_first_page_entries_and_get_topic_paths(self, entry_soups):
        entries = []
        all_pages_to_be_fetched = []
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = [
                executor.submit(self.parser.get_all_pages_to_be_fetched, entry_soup)
                for entry_soup in entry_soups
            ]

            for future in as_completed(futures):
                (
                    topic_path,
                    entries_for_one_soup,
                    pages_to_be_fetched,
                    status,
                ) = future.result()
                if status == FetchStatus.COMPLETED:
                    all_pages_to_be_fetched.append(pages_to_be_fetched)
                    entries.extend(entries_for_one_soup)
                elif status == FetchStatus.NOT_PROCESSED:
                    # Either topic or entry is not there / deleted etc.
                    pass
                else:
                    logger.error(
                        f"LogicalInconsistency for {topic_path}... Code needs to be "
                        f"fixed."
                    )
                    raise LogicalInconsistencyError

        paths = [
            topic_path
            for topic_path_gen in all_pages_to_be_fetched
            for topic_path in topic_path_gen
        ]
        for i in range(0, len(paths), settings.FIRST_PAGE_SERVICE_PUBLISH_BATCH):
            message = " ".join(paths[i : i + settings.FIRST_PAGE_SERVICE_PUBLISH_BATCH])
            self.publisher.publish(message)

        self.persist_entries(entries)
        self.persist_topics(set([e["topic-path"] for e in entries]))
        return len(entries), len(paths)

    def crawl_parse_persist(self, entry_ids):
        start_time = time.perf_counter()
        entries_to_fetch = []

        topic_paths = set()
        entry_ids_with_soups = [
            e for e in self.get_soups(entry_ids) if e[1] is not None
        ]
        # Let's remove entries that their topics are the same.
        for entry_id_soup in entry_ids_with_soups:
            entry_id, soup = entry_id_soup
            topic_path = self.parser.get_topic_path(soup)
            if topic_path not in topic_paths:
                # Check Cache to make sure these topic_paths are not already fetched.
                if not self.is_topic_in_cache(topic_path):
                    entries_to_fetch.append((entry_id, soup))
                    topic_paths.add(topic_path)

        total_num_of_entries = 0
        total_num_of_topic_paths = 0
        if len(entries_to_fetch) > 0:
            entry_ids, soups = zip(*entries_to_fetch)
            logger.info(
                f"Followings are the topics that will be fetched: {topic_paths}"
            )
            (
                total_num_of_entries,
                total_num_of_topic_paths,
            ) = self.collect_first_page_entries_and_get_topic_paths(soups)

        message = (
            f"{total_num_of_entries} entries persisted and "
            f"{total_num_of_topic_paths} topic paths published in "
            f"{(time.perf_counter() - start_time):.2f} seconds."
        )
        logger.info(message)
        wasabi.msg.good(message)

        return total_num_of_entries


class TopicPageParserManager(EksiParserManager):
    """Objects of this class are responsible for
    - Receiving topic_paths (['/pena---85853?p=2', ...])
    - Downloading & persisting all the entries in the each topic_path page into
      Cloud storage.

    Reference: Role #4

    """

    def collect_entries_from_topic_paths(self, topic_paths):
        entries = []
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = [
                executor.submit(self.parser.parse_page, topic_path)
                for topic_path in topic_paths
            ]
            for future in as_completed(futures):
                entries.extend(future.result())

        total_num_of_entries = len(entries)
        self.persist_entries(entries)

        msg = (
            f"{total_num_of_entries} entries from {len(topic_paths)} topic "
            f"paths are published..."
        )
        logger.info(msg)
        wasabi.msg.good(msg)
        return total_num_of_entries


if __name__ == "__main__":
    first_page_manager = FirstPageParserManager(persist=False, use_cache=False)
    first_page_manager.crawl_parse_persist(range(1503200, 1503221))
    # first_page_manager.crawl_parse_persist(range(1502300, 1502401))
    # first_page_manager.crawl_parse_persist(range(1502400, 1502501))

    topic_page_manager = TopicPageParserManager(persist=False, use_cache=False)
    topic_page_manager.collect_entries_from_topic_paths(
        ["/pena--31782?p=5", "/pena--31782?p=6"]
    )
