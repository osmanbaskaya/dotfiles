from itertools import cycle
import logging
from time import sleep

from google.cloud import monitoring_v3
from google.cloud import pubsub_v1
from google.cloud.monitoring_v3 import query


logger = logging.getLogger(__name__)


class PubSubPublisher:
    def __init__(self, project, topic, batch_settings=None):
        self.project = project
        self.topic = topic

        self._metric_client = monitoring_v3.MetricServiceClient()

        if batch_settings is not None:
            batch_settings = pubsub_v1.types.BatchSettings(**batch_settings)

        self.publisher_client = pubsub_v1.PublisherClient(batch_settings=batch_settings)

        self.topic_path = self.publisher_client.topic_path(self.project, self.topic)

    def get_num_of_undelivered_messages(self, subscription):
        metric = "pubsub.googleapis.com/subscription/num_undelivered_messages"
        result = query.Query(
            self._metric_client,
            self.project,
            metric_type=metric,
            days=0,
            hours=0,
            minutes=10,
        )
        result = result.as_dataframe()
        return (
            result["pubsub_subscription"][self.project][subscription][0]
            if len(result) != 0
            else 0
        )

    def publish(self, message, *args, **kwargs):
        data = message.encode("utf8")
        return self.publisher_client.publish(self.topic_path, data, *args, **kwargs)

    @staticmethod
    def _compute_next_pooling_time(
        pooling_time,
        num_of_undelivered_message_start,
        current_num_of_undelivered_message,
        batch_size,
    ):
        processed_messages_per_second = (
            num_of_undelivered_message_start
            + batch_size
            - current_num_of_undelivered_message
        ) / pooling_time
        return batch_size / processed_messages_per_second / 2


class EksiEntryIdPublisher(PubSubPublisher):
    def _publish(self, starting_id, ending_id, batch_size):
        last_published_id = min(ending_id, starting_id + batch_size)
        for n in range(starting_id, last_published_id):
            data = f"{n}".encode("utf-8")
            self.publisher_client.publish(self.topic_path, data)

        return last_published_id

    def publish(self, starting_id, ending_id, pooling_time=5 * 60, batch_size=5000):
        """

        Args:
            starting_id: Starting entry id
            ending_id: Ending entry id.
            pooling_time (int): 5 minutes default starting pooling time.
            batch_size (int): Indicates how many messages will be published at
            once.

        Returns: None
        """
        adaptive_pooling = pooling_time
        num_of_undelivered_message = self.get_num_of_undelivered_messages()
        last_published_message_id = starting_id - 1

        while last_published_message_id < ending_id:
            try:
                if num_of_undelivered_message < batch_size:
                    last_published_message_id = self._publish(
                        last_published_message_id, ending_id, batch_size
                    )
                logger.info(f"Last published message id is {last_published_message_id}")
                logger.info(
                    f"Publisher is going to sleep now for {adaptive_pooling} seconds."
                )
                sleep(adaptive_pooling)
                current_num_of_undelivered_message = (
                    self.get_num_of_undelivered_messages()
                )
                adaptive_pooling = self._compute_next_pooling_time(
                    adaptive_pooling,
                    num_of_undelivered_message,
                    current_num_of_undelivered_message,
                    batch_size,
                )
                num_of_undelivered_message = current_num_of_undelivered_message
            except KeyboardInterrupt:
                logger.info(f"Last published message id is {last_published_message_id}")
                logger.info("Gracefully shutting down the Publisher.")
                break

        logger.info(
            f"All messages are published. The last entry id was "
            f"{last_published_message_id}"
        )
        logger.info("Gracefully shutting down the Publisher.")


class EksiPageTopicPublisher(PubSubPublisher):
    def publish(self, message):
        data = message.encode("utf8")
        return self.publisher_client.publish(self.topic_path, data)


class EksiPagePathMultipleTopicRandomPublisher:
    def __init__(self, project, topics, batch_settings=None):
        """Randomly publish the topics."""
        self.topics = topics
        self.project = project
        self.batch_settings = batch_settings
        self._publishers = cycle(
            [
                (
                    topic,
                    EksiPageTopicPublisher(self.project, topic, self.batch_settings),
                )
                for topic in self.topics
            ]
        )

    def publish(self, message):
        topic, publisher = next(self._publishers)
        receipt = publisher.publish(message)
        logger.debug(f"Message is published to the '{topic}' with receipt {receipt}")
