from itertools import cycle
import logging

from google.cloud import monitoring_v3, pubsub_v1
from google.cloud.monitoring_v3 import query

logger = logging.getLogger(__name__)


class PubSubPublisher:
    def __init__(self, project, topic, batch_settings=None):
        self.project = project
        self.topic = topic

        self._metric_client = monitoring_v3.MetricServiceClient()

        batch_settings = batch_settings or {}

        if batch_settings is not None:
            batch_settings = pubsub_v1.types.BatchSettings(**batch_settings)

        self.publisher_client = pubsub_v1.PublisherClient(batch_settings=batch_settings)

        self.topic_path = self.publisher_client.topic_path(self.project, self.topic)

    def get_num_of_undelivered_messages(self, subscription):
        metric = "pubsub.googleapis.com/subscription/num_undelivered_messages"
        result = query.Query(
            self._metric_client,
            self.project,
            metric_type=metric,
            days=0,
            hours=0,
            minutes=10,
        )
        result = result.as_dataframe()
        return (
            result["pubsub_subscription"][self.project][subscription][0]
            if len(result) != 0
            else 0
        )

    def publish(self, message, *args, **kwargs):
        data = message.encode("utf8")
        return self.publisher_client.publish(self.topic_path, data, *args, **kwargs)

    @staticmethod
    def _compute_next_pooling_time(
        pooling_time,
        num_of_undelivered_message_start,
        current_num_of_undelivered_message,
        batch_size,
    ):
        processed_messages_per_second = (
            num_of_undelivered_message_start
            + batch_size
            - current_num_of_undelivered_message
        ) / pooling_time
        return batch_size / processed_messages_per_second / 2


class EksiPageTopicPublisher(PubSubPublisher):
    pass


class EksiPagePathMultipleTopicRandomPublisher:
    def __init__(self, project, topics, batch_settings=None):
        """Randomly publish the topics."""
        self.topics = topics
        self.project = project
        self.batch_settings = batch_settings
        self._publishers = cycle(
            [
                (
                    topic,
                    EksiPageTopicPublisher(self.project, topic, self.batch_settings),
                )
                for topic in self.topics
            ]
        )

    def publish(self, message):
        topic, publisher = next(self._publishers)
        publisher.publish(message)
        logger.debug(f"Message is published to the '{topic}'")
