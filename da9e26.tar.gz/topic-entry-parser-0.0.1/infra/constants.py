REGIONS_ZONES = [
    ("us-central1", "iowa"),
    ("us-east1", "south-carolina"),
    ("us-east4", "virginia"),
    ("europe-west1", "belgium"),
    ("europe-west2", "london"),
    ("asia-east2", "hong-kong"),
    ("asia-northeast1", "tokyo"),
    ("asia-northeast2", "osaka"),
    ("europe-west3", "frankfurt"),
    ("europe-west6", "zurich"),
    ("us-west3", "salt-lake-city"),
    ("northamerica-northeast1", "montreal"),
    ("australia-southeast1", "sydney"),
    ("us-west2", "los-angeles"),
    ("us-west4", "las-vegas"),
    ("southamerica-east1", "sao"),
    ("Paulo", "asia-south1"),
    ("mumbai", "asia-southeast2"),
    ("jakarta", "asia-northeast3"),
]

PREFIX = "eksi"
PROJECT_ID = "hardy-nation-291804"
