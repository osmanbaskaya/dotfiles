import os

CACHE_MANAGER_HOST = "35.222.138.220"


def run_command(command, instance_name, num_replicas):
    for replica in range(1, num_replicas + 1):
        os.system(command.format(instance_name, replica, instance_name, replica))


def create_first_page_consumer(num_replicas=1):
    instance_name = "first-page-consumer"
    command = (
        "gcloud beta compute --project=hardy-nation-291804 instances "
        "create-with-container {}-{} --zone=us-central1-a "
        "--machine-type=e2-medium "
        "--subnet=default --network-tier=PREMIUM "
        "--metadata=google-logging-enabled=true --no-restart-on-failure "
        "--maintenance-policy=TERMINATE --preemptible "
        "--service-account=256829463812-compute@developer.gserviceaccount.com "
        "--scopes=https://www.googleapis.com/auth/cloud-platform "
        "--image=cos-stable-85-13310-1041-24 --image-project=cos-cloud "
        "--boot-disk-size=10GB --boot-disk-type=pd-standard "
        "--boot-disk-device-name={}-{}  "
        "--container-image=gcr.io/hardy-nation-291804/github.com/imagination-ai"
        "/eksi-crawler:latest --container-restart-policy=always "
        "--container-env=APP_TYPE=first-page-consumer," +
        "CACHE_MANAGER_HOST={} ".format(CACHE_MANAGER_HOST) +
        "--labels=app-type=first-page-consumer,codename=soursweet,"
        "container-vm=cos-stable-85-13310-1041-24"
    )
    run_command(command, instance_name, num_replicas)


def create_redis_service():
    instance_name = "redis-service"
    command = (
        "gcloud beta compute --project=hardy-nation-291804 instances "
        "create-with-container {} --zone=us-central1-a "
        "--machine-type=e2-highmem-2 --subnet=default --network-tier=PREMIUM "
        "--metadata=google-logging-enabled=true --no-restart-on-failure "
        "--maintenance-policy=TERMINATE --preemptible "
        "--service-account=256829463812-compute@developer.gserviceaccount.com "
        "--scopes=https://www.googleapis.com/auth/cloud-platform "
        "--image=cos-stable-85-13310-1041-28 --image-project=cos-cloud "
        "--boot-disk-size=50GB --boot-disk-type=pd-standard "
        "--boot-disk-device-name={} "
        "--container-image=gcr.io/hardy-nation-291804/redis "
        "--container-restart-policy=always --labels=app-type=redis-service,"
        "codename=soursweet"
        "container-vm=cos-stable-85-13310-1041-28".format(instance_name, instance_name)
    )
    os.system(command)


def create_cache_manager():
    instance_type = "cache-manager"
    command = (
        "gcloud beta compute --project=hardy-nation-291804 instances "
        "create-with-container {} --zone=us-central1-a --machine-type=e2-micro "
        "--subnet=default --network-tier=PREMIUM "
        "--metadata=google-logging-enabled=true --no-restart-on-failure "
        "--maintenance-policy=TERMINATE --preemptible "
        "--service-account=256829463812-compute@developer.gserviceaccount.com "
        "--scopes=https://www.googleapis.com/auth/cloud-platform --tags=http-server "
        "--image=cos-stable-85-13310-1041-28 --image-project=cos-cloud "
        "--boot-disk-size=10GB --boot-disk-type=pd-standard --boot-disk-device-name={} "
        "--container-image=gcr.io/hardy-nation-291804/github.com/imagination-ai/eksi"
        "-crawler --container-restart-policy=always "
        "--container-env=APP_TYPE=cache-manager,REDIS_SERVICE_HOST=redis-service,"
        "APP_PORT=80 --labels=app-type=cache-manager,"
        "container-vm=cos-stable-85-13310-1041-28,codename=soursweet"
    )
    command = command.format(instance_type, instance_type)
    os.system(command)


def create_publisher():
    command = (
        "gcloud beta compute --project=hardy-nation-291804 instances "
        "create-with-container entry-id-publisher --zone=us-central1-a "
        "--machine-type=e2-micro --subnet=default --network-tier=PREMIUM "
        "--metadata=google-logging-enabled=true --no-restart-on-failure "
        "--maintenance-policy=TERMINATE --preemptible "
        "--service-account=256829463812-compute@developer.gserviceaccount.com "
        "--scopes=https://www.googleapis.com/auth/cloud-platform "
        "--tags=http-server --image=cos-stable-85-13310-1041-28 "
        "--image-project=cos-cloud --boot-disk-size=10GB "
        "--boot-disk-type=pd-standard --boot-disk-device-name=entry-id-publisher "
        "--container-image=gcr.io/hardy-nation-291804/github.com/imagination-ai"
        "/eksi-crawler --container-restart-policy=always "
        "--container-env=APP_TYPE=publisher,APP_PORT=80 "
        "--labels=app-type=publisher,codename=soursweet,"
        "container-vm=cos-stable-85-13310-1041-28"
    )
    os.system(command)


# create_redis_service()
# create_cache_manager()
# create_publisher()
create_first_page_consumer(2)
