import os
from argparse import ArgumentParser

from infra.constants import PREFIX
from infra.constants import REGIONS_ZONES


def deploy_functions():
    parser = ArgumentParser()
    parser.add_argument("--env-vars", default=None, required=False)

    args = parser.parse_args()

    command = (
        "gcloud functions deploy topic-page-consumer-{} --region {} "
        "--runtime=python38 --memory 256MB --service-account "
        "hardy-nation-291804@appspot.gserviceaccount.com --source "
        "https://source.developers.google.com/projects/hardy-nation-291804/repos"
        "/github_imagination-ai_eksi-crawler/moveable-aliases/main/paths"
        "/cloud_functions/crawl_parse_persist --entry-point topic_page_download "
        "--max-instances 3 --trigger-topic {} --timeout 540s "
    )

    if args.env_vars is not None:
        command += "--set-env-vars {} ".format(args.env_vars)

    command += "&"

    functions = []
    total_regions = len(REGIONS_ZONES)
    for i, (region, region_name) in enumerate(REGIONS_ZONES, 1):
        print(f"Cloud Function {i}/{total_regions} is being created...")
        c = command.format(region_name, region, f"{PREFIX}-{region_name}")
        functions.append(c)
        os.system(c)
        break


deploy_functions()
