from setuptools import find_packages
from setuptools import setup

# import sys
# from pathlib import Path

# def err(msg):
#     sys.stderr.write(msg)
#     sys.exit(1)
#
#
# def parse_requirements():
#     subgroup_offset = "#-# "
#     dependencies = {}
#     subgroup = "dummy-subgroup"
#     req_file = Path(__file__).parent / "requirements.txt"
#     if not req_file.is_file():
#         req_file = Path(__file__).parent / "requires.txt"
#     for line in open(req_file):
#         line = line.strip()
#         if line.startswith(subgroup_offset):
#             subgroup = line.rsplit(maxsplit=1)[1]
#             dependencies[subgroup] = []
#         elif line != "":
#             dependencies[subgroup].append(line)
#
#     if "core" not in dependencies or "dummy-subgroup" in dependencies:
#         err("core should be in the requirements.txt as '#-# core'")
#
#     return dependencies


# reqs = parse_requirements()
# print(reqs)

reqs = [
    "requests~=2.24.0",
    "beautifulsoup4~=4.9.3",
    "urllib3~=1.25.10",
    "fastapi[all]==0.61.1",
    "uvicorn==0.11.8",
    "setuptools~=50.3.0",
    "dill~=0.3.3",
    "cloudpickle",
    "gunicorn==20.0.4",
    "google-cloud-storage",
    "PyYAML~=5.3.1",
    "redis==3.5.3",
    "google-cloud-monitoring",
    "google-cloud-pubsub",
]
setup(
    name="topic-entry-parser",
    version="0.0.1",
    packages=find_packages(exclude=["tests", "cloud_functions"]),
    package_dir={"": "."},
    # install_requires=reqs["core"],
    install_requires=reqs,
    package_data={"": ["*.yaml", "*.txt"]},
    include_package_data=True,
    # extras_require={
    #     extra: extra_reqs for extra, extra_reqs in reqs.items() if extra != "core"
    # },
    python_requires=">=3.8",
)
